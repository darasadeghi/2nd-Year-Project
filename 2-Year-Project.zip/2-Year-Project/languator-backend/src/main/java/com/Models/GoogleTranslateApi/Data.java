package com.Models.GoogleTranslateApi;

import java.util.ArrayList;

public class Data {
	public ArrayList<Translations> translations;
}
