package com.Models.GoogleTranslateApi;

public class GoogleTranslateApiResponse {
	public Data data;
}
