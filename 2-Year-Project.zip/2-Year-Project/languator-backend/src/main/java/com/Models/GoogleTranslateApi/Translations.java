package com.Models.GoogleTranslateApi;

public class Translations {
	public String translatedText;
	public String detectedSourceLanguage;
}
