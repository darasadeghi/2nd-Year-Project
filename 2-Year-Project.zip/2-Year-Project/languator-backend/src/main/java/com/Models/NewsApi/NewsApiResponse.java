package com.Models.NewsApi;

import java.util.ArrayList;


public class NewsApiResponse {
	public String status;
	public int totalResults;
	public ArrayList<Article> articles;
}
