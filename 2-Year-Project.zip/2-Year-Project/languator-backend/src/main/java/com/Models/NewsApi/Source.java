package com.Models.NewsApi;

public class Source {
	public String id;
	public String name;
}