enum Language{
    English,
    French,
    Spanish
};

export default Language;