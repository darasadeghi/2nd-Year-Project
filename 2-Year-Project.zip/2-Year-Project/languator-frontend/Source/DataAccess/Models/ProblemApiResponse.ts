class ProblemApiResponse{
    english : string;
    french : string;
    spanish : string
}

export default ProblemApiResponse;
