enum Tab{
    Problem,
    Solution,
    Leaderboard,
    Attempt
};

export default Tab;